import { Bloodavailability } from './bloodavailability';

describe('Bloodavailability', () => {
  it('should create an instance', () => {
    expect(new Bloodavailability()).toBeTruthy();
  });
});
