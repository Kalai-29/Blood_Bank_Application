import { Bloodbankcenter } from './bloodbankcenter';

describe('Bloodbankcenter', () => {
  it('should create an instance', () => {
    expect(new Bloodbankcenter()).toBeTruthy();
  });
});
