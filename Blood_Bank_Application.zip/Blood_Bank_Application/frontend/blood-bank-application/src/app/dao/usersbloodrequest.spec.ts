import { Usersbloodrequest } from './usersbloodrequest';

describe('Usersbloodrequest', () => {
  it('should create an instance', () => {
    expect(new Usersbloodrequest()).toBeTruthy();
  });
});
