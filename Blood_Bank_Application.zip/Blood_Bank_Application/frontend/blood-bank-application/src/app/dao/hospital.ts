export class Hospital {
        hospitalid:number;
        hospitalname:string;
        hospitalphonenumber:string;
        hospitalemail:string;
        role:string;
    
        constructor(hospitalid:number,hospitalname:string,hospitalphonenumber:string,hospitalemail:string,role:string){
            this.hospitalid=hospitalid;
            this.hospitalname=hospitalname;
            this.hospitalphonenumber=hospitalphonenumber;
            this.hospitalemail=hospitalemail;
            this.role=role;
           
        }
      
    }

