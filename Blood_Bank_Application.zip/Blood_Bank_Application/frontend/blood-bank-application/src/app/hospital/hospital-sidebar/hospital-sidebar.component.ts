import { Component } from '@angular/core';

@Component({
  selector: 'app-hospital-sidebar',
  standalone: false,
  
  templateUrl: './hospital-sidebar.component.html',
  styleUrl: './hospital-sidebar.component.css'
})
export class HospitalSidebarComponent {

}
