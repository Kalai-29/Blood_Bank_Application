import { Component } from '@angular/core';

@Component({
  selector: 'app-bloodbank-sidebar',
  standalone: false,
  
  templateUrl: './bloodbank-sidebar.component.html',
  styleUrl: './bloodbank-sidebar.component.css'
})
export class BloodbankSidebarComponent {

}
