import { Component } from '@angular/core';

@Component({
  selector: 'app-addbloodavailability',
  standalone: false,
  
  templateUrl: './addbloodavailability.component.html',
  styleUrl: './addbloodavailability.component.css'
})
export class AddbloodavailabilityComponent {

}
