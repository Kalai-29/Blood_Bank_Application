import { Component } from '@angular/core';

@Component({
  selector: 'app-terms-and-condition',
  standalone: false,
  
  templateUrl: './terms-and-condition.component.html',
  styleUrl: './terms-and-condition.component.css'
})
export class TermsAndConditionComponent {

}
