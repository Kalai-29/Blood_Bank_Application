import { Component } from '@angular/core';

@Component({
  selector: 'app-users-sidebar',
  standalone: false,
  
  templateUrl: './users-sidebar.component.html',
  styleUrl: './users-sidebar.component.css'
})
export class UsersSidebarComponent {

}
