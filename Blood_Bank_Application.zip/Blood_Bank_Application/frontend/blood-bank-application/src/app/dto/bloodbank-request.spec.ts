import { BloodbankRequest } from './bloodbank-request';

describe('BloodbankRequest', () => {
  it('should create an instance', () => {
    expect(new BloodbankRequest()).toBeTruthy();
  });
});
