import { HospitalRequest } from './hospital-request';

describe('HospitalRequest', () => {
  it('should create an instance', () => {
    expect(new HospitalRequest()).toBeTruthy();
  });
});
