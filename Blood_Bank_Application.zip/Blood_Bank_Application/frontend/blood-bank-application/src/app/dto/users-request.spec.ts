import { UsersRequest } from './users-request';

describe('UsersRequest', () => {
  it('should create an instance', () => {
    expect(new UsersRequest()).toBeTruthy();
  });
});
