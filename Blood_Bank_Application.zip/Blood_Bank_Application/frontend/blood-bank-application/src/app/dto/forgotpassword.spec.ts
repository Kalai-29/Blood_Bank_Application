import { Forgotpassword } from './forgotpassword';

describe('Forgotpassword', () => {
  it('should create an instance', () => {
    expect(new Forgotpassword()).toBeTruthy();
  });
});
