import { Loginrequest } from './loginrequest';

describe('Loginrequest', () => {
  it('should create an instance', () => {
    expect(new Loginrequest()).toBeTruthy();
  });
});
