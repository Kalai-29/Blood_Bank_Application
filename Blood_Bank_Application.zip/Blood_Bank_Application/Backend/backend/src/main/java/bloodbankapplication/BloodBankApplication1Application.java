package bloodbankapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloodBankApplication1Application {

	public static void main(String[] args) {
		SpringApplication.run(BloodBankApplication1Application.class, args);
	}

}
