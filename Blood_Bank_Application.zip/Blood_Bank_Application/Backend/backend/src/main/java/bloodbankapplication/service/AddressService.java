package bloodbankapplication.service;

import java.util.List;

import bloodbankapplication.dao.Address;

public interface AddressService {

	public List<Address> getAllAddress();
	
	

}
